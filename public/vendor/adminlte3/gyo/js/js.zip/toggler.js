let passwordToggler = document.querySelector('.toggle-password');
let passwordInput   = document.querySelector('#password');
let icon            = passwordToggler.querySelector('.icon');
  
passwordToggler.addEventListener('click', (e)=>{
  passwordInput.type = (passwordInput.type == 'password') ? 'text' : 'password';
  icon.innerHTML     = (icon.innerHTML == 'visibility') ? 'visibility_off' : 'visibility';
});